// ai-report-management.js

document.addEventListener('DOMContentLoaded', () => {
    // المتطلب الثالث: نقل معرف السجل الطبي من التخزين المحلي إلى حقل الإدخال
    const medicalRecordIdInput = document.getElementById('medicalRecordId');
    const latestRecordId = getLatestRecordId(); // getLatestRecordId is defined in script.js

    if (latestRecordId && medicalRecordIdInput) {
        medicalRecordIdInput.value = latestRecordId;
    }

    // توليد وتعبئة معرف تقرير الذكاء الاصطناعي العشوائي عند تحميل الصفحة
    // توليد وتعبئة معرف تقرير الذكاء الاصطناعي العشوائي عند تحميل الصفحة
    const randomAIReportIdInput = document.getElementById('randomAIReportId');
    if (randomAIReportIdInput) {
        randomAIReportIdInput.value = generateUniqueId('AIREP');
    }
    const requestForm = document.getElementById('requestAIReportForm');
    const searchForm = document.getElementById('searchAIReportForm');
    const requestMessage = document.getElementById('requestMessage');
    const searchMessage = document.getElementById('searchMessage');
    const searchResultsContainer = document.getElementById('searchResults');
    const reportsTableBody = document.getElementById('reportsTableBody');

    // بيانات تقارير وهمية للمحاكاة
    let aiReports = [
        { id: 3001, recordId: "user123", type: "ملخص وتحليل", date: "2024-11-20", status: "مكتمل", content: "ملخص شامل لنتائج التحاليل، لا توجد مؤشرات حرجة." },
        { id: 3002, recordId: "user123", type: "تدقيق التشخيص المقترح", date: "2024-11-22", status: "مكتمل", content: "يتفق الذكاء الاصطناعي مع التشخيص المقترح بنسبة 95%." },
        { id: 3003, recordId: "user456", type: "اقتراح خطة علاجية", date: "2024-11-15", status: "مكتمل", content: "اقتراح بتعديل جرعة الدواء 'س' بناءً على الوزن." },
        { id: 3004, recordId: "user123", type: "تنبيهات حرجة", date: "2024-11-24", status: "قيد الإنشاء", content: "" },
    ];

    // معالجة نموذج طلب تقرير الذكاء الاصطناعي
    requestForm.addEventListener('submit', (event) => {
        event.preventDefault();
        
        const recordId = document.getElementById('medicalRecordId').value.trim(); // نستخدم القيمة المعبأة أو المدخلة
        const reportTypeSelect = document.getElementById('reportType');
        const reportType = reportTypeSelect.options[reportTypeSelect.selectedIndex].text;
        const reportTypeValue = reportTypeSelect.value;

        if (!recordId) {
            requestMessage.textContent = 'الرجاء إدخال معرف السجل الطبي.';
            requestMessage.style.color = 'red';
            return;
        }

        // محاكاة عملية إنشاء التقرير
        const newReport = {
            id: document.getElementById('randomAIReportId').value, // استخدام المعرف الذي تم توليده عند تحميل الصفحة
            recordId: recordId,
            type: reportType,
            date: new Date().toISOString().slice(0, 10),
            status: "قيد الإنشاء",
            content: ""
        };

        aiReports.push(newReport);

        // المتطلب الرابع: تثبيت معرف تقرير الذكاء الاصطناعي بعد الإنشاء
        setAiReportId(newReport.id); // حفظ المعرف في التخزين المحلي
        requestMessage.textContent = `تم إرسال طلب إنشاء تقرير "${reportType}" للسجل ${recordId}. تم تثبيت معرف التقرير: ${newReport.id}.`;
        requestMessage.style.color = 'blue';
        
        // تعديل: لا نقوم بعمل reset للنموذج بالكامل للحفاظ على المعرفات ظاهرة
        // فقط نقوم بمسح نوع التقرير المختار
        reportTypeSelect.value = "";
        
        // لا نقوم بإعادة توليد المعرف، بل نثبته كما هو مطلوب
        searchResultsContainer.style.display = 'none'; // إخفاء نتائج البحث السابقة

        console.log('طلب تقرير ذكاء اصطناعي جديد:', newReport);
    });

    // معالجة نموذج البحث في التقارير
    searchForm.addEventListener('submit', (event) => {
        event.preventDefault();
        
        const searchRecordId = document.getElementById('searchRecordId').value.trim(); // نستخدم القيمة المعبأة أو المدخلة

        if (!searchRecordId) {
            searchMessage.textContent = 'الرجاء إدخال معرف السجل الطبي للبحث.';
            searchMessage.style.color = 'red';
            searchResultsContainer.style.display = 'none';
            return;
        }

        // تصفية التقارير بناءً على معرف السجل الطبي
        const results = aiReports.filter(report => report.recordId === searchRecordId);

        searchMessage.textContent = '';
        searchMessage.style.color = 'initial';
        renderSearchResults(results);
    });

    // عرض نتائج البحث في الجدول
    function renderSearchResults(results) {
        reportsTableBody.innerHTML = ''; // مسح النتائج السابقة

        if (results.length === 0) {
            reportsTableBody.innerHTML = `<tr><td colspan="6" style="text-align: center;">لا توجد تقارير ذكاء اصطناعي لهذا السجل الطبي.</td></tr>`;
            searchResultsContainer.style.display = 'block';
            return;
        }

        results.forEach((report, index) => {
            const row = reportsTableBody.insertRow();
            let statusBadge = '';
            let actionButtons = '';

            if (report.status === 'مكتمل') {
                statusBadge = '<span class="status-badge status-completed">مكتمل</span>';
                actionButtons = `<button class="btn-small btn-info" onclick="viewReport('${report.id}')"><i class="fas fa-eye"></i> عرض</button>`;
            } else if (report.status === 'قيد الإنشاء') {
                statusBadge = '<span class="status-badge status-pending">قيد الإنشاء</span>';
                actionButtons = `<button class="btn-small btn-warning" onclick="updateReportStatus('${report.id}')"><i class="fas fa-sync-alt"></i> تحديث</button>`;
            } else {
                statusBadge = '<span class="status-badge status-error">فشل</span>';
                actionButtons = `<button class="btn-small btn-danger" onclick="retryReport('${report.id}')"><i class="fas fa-redo"></i> إعادة المحاولة</button>`;
            }

            row.innerHTML = `
                <td>${index + 1}</td>
                <td>${report.id}</td>
                <td>${report.type}</td>
                <td>${report.date}</td>
                <td>${statusBadge}</td>
                <td>
                    ${actionButtons}
                    <button class="btn-small btn-outline-danger" onclick="deleteReport('${report.id}')"><i class="fas fa-trash"></i></button>
                </td>
            `;
        });

        searchResultsContainer.style.display = 'block';
    }

    // وظيفة عرض التقرير
    window.viewReport = (reportId) => {
        const report = aiReports.find(r => String(r.id) === String(reportId));
        if (report) {
            // إنشاء نافذة منبثقة لعرض التقرير
            const modalHtml = `
                <div id="reportModal" class="modal-overlay">
                    <div class="modal-content report-modal">
                        <div class="modal-header">
                            <h3>تقرير الذكاء الاصطناعي: ${report.id}</h3>
                            <button onclick="closeModal()" class="close-btn">&times;</button>
                        </div>
                        <div class="modal-body">
                            <div class="report-meta">
                                <span><strong>النوع:</strong> ${report.type}</span>
                                <span><strong>التاريخ:</strong> ${report.date}</span>
                            </div>
                            <div class="report-text-content">
                                <h4>محتوى التحليل:</h4>
                                <p>${report.content || "جاري معالجة البيانات العميقة..."}</p>
                                <div class="ai-disclaimer">
                                    <i class="fas fa-exclamation-triangle"></i>
                                    ملاحظة مهمة: هذه التقارير هي نماذج توضيحية لأتمتة العملية، وتتطلب دائمًا مراجعة وتدقيقًا من قبل الفريق الطبي المؤهل.
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-secondary" onclick="window.print()"><i class="fas fa-print"></i> طباعة التقرير</button>
                        </div>
                    </div>
                </div>
            `;
            document.body.insertAdjacentHTML('beforeend', modalHtml);
        }
    };

    // وظيفة تحديث حالة التقرير
    window.updateReportStatus = (reportId) => {
        const report = aiReports.find(r => String(r.id) === String(reportId));
        if (report) {
            report.status = 'مكتمل';
            report.content = "تم تحديث البيانات بنجاح. يظهر التحليل استقراراً في المؤشرات الحيوية مع توصية بمتابعة الخطة العلاجية الحالية.";
            alert(`تم تحديث حالة التقرير ${reportId} إلى مكتمل.`);
            refreshSearchResults();
        }
    };

    // وظيفة إعادة المحاولة
    window.retryReport = (reportId) => {
        const report = aiReports.find(r => String(r.id) === String(reportId));
        if (report) {
            report.status = 'قيد الإنشاء';
            alert(`جاري إعادة محاولة إنشاء التقرير ${reportId}...`);
            refreshSearchResults();
            
            // محاكاة اكتمال بعد ثانيتين
            setTimeout(() => {
                report.status = 'مكتمل';
                report.content = "تمت إعادة المعالجة بنجاح. تم تصحيح الأخطاء في قراءة السجل الطبي.";
                refreshSearchResults();
            }, 2000);
        }
    };

    // وظيفة حذف التقرير
    window.deleteReport = (reportId) => {
        if (confirm(`هل أنت متأكد من حذف التقرير ذو المعرف ${reportId}؟`)) {
            aiReports = aiReports.filter(r => String(r.id) !== String(reportId));
            refreshSearchResults();
        }
    };

    // وظيفة مساعدة لتحديث الجدول
    function refreshSearchResults() {
        const searchRecordId = document.getElementById('searchRecordId').value.trim();
        if (searchRecordId) {
            const results = aiReports.filter(report => report.recordId === searchRecordId);
            renderSearchResults(results);
        }
    }

    window.closeModal = () => {
        const modal = document.getElementById('reportModal');
        if (modal) modal.remove();
    };
});
