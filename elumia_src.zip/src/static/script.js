// Mobile Navigation
const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');

if (hamburger) {
    hamburger.addEventListener('click', () => {
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
    });
}

// Dropdown Toggle for Mobile
document.querySelectorAll('.dropdown > .nav-link').forEach(dropdownLink => {
    dropdownLink.addEventListener('click', function(e) {
        if (window.innerWidth <= 768) {
            e.preventDefault();
            e.stopPropagation();
            const dropdownContent = this.nextElementSibling;
            const isActive = dropdownContent.classList.contains('active');
            
            // Close all other dropdowns
            document.querySelectorAll('.dropdown-content').forEach(content => {
                content.classList.remove('active');
            });
            
            if (!isActive) {
                dropdownContent.classList.add('active');
            }
        }
    });
});

// Close mobile menu when clicking on a link (except dropdown triggers)
document.querySelectorAll('.nav-link:not(.dropdown > .nav-link)').forEach(n => n.addEventListener('click', () => {
    if (hamburger) hamburger.classList.remove('active');
    if (navMenu) navMenu.classList.remove('active');
}));

// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        const href = this.getAttribute('href');
        if (href.startsWith('#') && href.length > 1) {
            e.preventDefault();
            const target = document.querySelector(href);
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        }
    });
});

// Modal functionality
const loginModal = document.getElementById('loginModal');
const registerModal = document.getElementById('registerModal');
const loginBtns = document.querySelectorAll('.login-btn, a[href="#login"]');
const showRegisterLink = document.getElementById('showRegister');
const showLoginLink = document.getElementById('showLogin');
const closeBtns = document.querySelectorAll('.close');

// Show login modal
loginBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
        e.preventDefault();
        if (loginModal) loginModal.style.display = 'block';
    });
});

// Show register modal
if (showRegisterLink) {
    showRegisterLink.addEventListener('click', (e) => {
        e.preventDefault();
        if (loginModal) loginModal.style.display = 'none';
        if (registerModal) registerModal.style.display = 'block';
    });
}

// Show login modal from register
if (showLoginLink) {
    showLoginLink.addEventListener('click', (e) => {
        e.preventDefault();
        if (registerModal) registerModal.style.display = 'none';
        if (loginModal) loginModal.style.display = 'block';
    });
}

// Close modals
closeBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        if (loginModal) loginModal.style.display = 'none';
        if (registerModal) registerModal.style.display = 'none';
    });
});

// Close modal when clicking outside
window.addEventListener('click', (e) => {
    if (e.target === loginModal) {
        loginModal.style.display = 'none';
    }
    if (e.target === registerModal) {
        registerModal.style.display = 'none';
    }
});

// --- Authentication Logic (Local Storage Based) ---

const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');

if (loginForm) {
    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const formData = new FormData(loginForm);
        const username = formData.get('username');
        const password = formData.get('password');

        // Get users from localStorage
        const users = JSON.parse(localStorage.getItem('elumia_users') || '[]');
        
        // Simple check: find user with matching username and password
        const user = users.find(u => (u.username === username || u.email === username) && u.password === password);

        if (user) {
            alert('تم تسجيل الدخول بنجاح!');
            localStorage.setItem('isLoggedIn', 'true');
            localStorage.setItem('currentUser', JSON.stringify(user));
            window.location.href = 'dashboard.html';
        } else {
            // Default admin account for testing
            if (username === 'admin' && password === 'admin123') {
                alert('تم تسجيل الدخول بنجاح (حساب المسؤول)!');
                localStorage.setItem('isLoggedIn', 'true');
                localStorage.setItem('currentUser', JSON.stringify({username: 'admin', email: 'admin@elumia.com'}));
                window.location.href = 'dashboard.html';
            } else {
                alert('اسم المستخدم أو كلمة المرور غير صحيحة');
            }
        }
    });
}

if (registerForm) {
    registerForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const formData = new FormData(registerForm);
        const username = formData.get('username');
        const password = formData.get('password');

        const users = JSON.parse(localStorage.getItem('elumia_users') || '[]');
        
        // Check if user already exists
        if (users.some(u => u.username === username)) {
            alert('رقم الموبايل مسجل مسبقاً');
            return;
        }

        const newUser = {
            id: generateUniqueId('USER'),
            username,
            password
        };

        users.push(newUser);
        localStorage.setItem('elumia_users', JSON.stringify(users));

        alert('تم إنشاء الحساب بنجاح! يمكنك الآن تسجيل الدخول');
        if (registerModal) registerModal.style.display = 'none';
        if (loginModal) loginModal.style.display = 'block';
        registerForm.reset();
    });
}

// Authentication Guard & State Management
function checkAuth() {
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    const currentPage = window.location.pathname.split('/').pop();
    
    // Pages that require login
    const protectedPages = [
        'dashboard.html', 
        'medical-records.html', 
        'ai-report-management.html', 
        'doctor-selection.html',
        'appointments.html',
        'departments_management.html',
        'patients_management.html',
        'doctors_management.html',
        'pharmacy-management.html',
        'home-care-management.html',
        'physician-report-management.html',
        'payment-management.html'
    ];

    if (protectedPages.includes(currentPage) && !isLoggedIn) {
        window.location.href = 'index.html';
    }

    // Update UI if logged in
    if (isLoggedIn) {
        let user = JSON.parse(localStorage.getItem('currentUser') || '{}');
        
        // Ensure user has an ID
        if (!user.id) {
            user.id = generateUniqueId('USER');
            localStorage.setItem('currentUser', JSON.stringify(user));
            
            // Update in users list too
            const users = JSON.parse(localStorage.getItem('elumia_users') || '[]');
            const userIndex = users.findIndex(u => u.username === user.username || u.email === user.email);
            if (userIndex !== -1) {
                users[userIndex].id = user.id;
                localStorage.setItem('elumia_users', JSON.stringify(users));
            }
        }
        
        const userId = user.id;
        
        // Update Welcome Message
        const welcomeMsg = document.querySelector('.welcome-box h1');
        if (welcomeMsg) {
            welcomeMsg.textContent = `مرحباً بك، ${user.username || 'مستخدم Elumia-h9'}!`;
        }
        
        // Update User ID Display in Dashboard (Static Version)
        const welcomeBox = document.querySelector('.welcome-box');
        if (welcomeBox && !document.getElementById('dashboard-user-id')) {
            const idDisplay = document.createElement('p');
            idDisplay.id = 'dashboard-user-id';
            idDisplay.style.marginTop = '10px';
            idDisplay.style.fontSize = '0.9rem';
            idDisplay.style.color = 'var(--primary-light)';
            idDisplay.style.fontWeight = '600';
            idDisplay.innerHTML = `<i class="fas fa-id-badge"></i> معرف المستخدم التلقائي: <span style="color: var(--primary-color);">${userId}</span>`;
            welcomeBox.appendChild(idDisplay);
        }
        
        // Update User ID Display in Dashboard (Professional Version)
        const heroText = document.querySelector('.hero-text');
        if (heroText && !document.getElementById('dashboard-user-id-prof')) {
            const idDisplay = document.createElement('p');
            idDisplay.id = 'dashboard-user-id-prof';
            idDisplay.style.marginTop = '15px';
            idDisplay.style.padding = '8px 15px';
            idDisplay.style.backgroundColor = 'rgba(255, 255, 255, 0.1)';
            idDisplay.style.borderRadius = '8px';
            idDisplay.style.display = 'inline-block';
            idDisplay.style.fontSize = '0.95rem';
            idDisplay.style.color = '#ffffff';
            idDisplay.innerHTML = `<i class="fas fa-fingerprint"></i> المعرف الرقمي: <strong>${userId}</strong>`;
            heroText.appendChild(idDisplay);
        }
    }
}

function logout() {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('currentUser');
    alert('تم تسجيل الخروج بنجاح');
    window.location.href = 'index.html';
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', (e) => {
            e.preventDefault();
            logout();
        });
    }
});

// --- Helper Functions for ID Management ---

function generateUniqueId(prefix) {
    return prefix + '-' + Math.random().toString(36).substr(2, 9).toUpperCase();
}

function getUserId() {
    const user = JSON.parse(localStorage.getItem('currentUser') || '{}');
    return user.id || 'GUEST-' + Math.random().toString(36).substr(2, 5).toUpperCase();
}

function getLatestRecordId() {
    return localStorage.getItem('latestRecordId');
}

function setLatestRecordId(id) {
    localStorage.setItem('latestRecordId', id);
}

function getAiReportId() {
    return localStorage.getItem('latestAiReportId');
}

function setAiReportId(id) {
    localStorage.setItem('latestAiReportId', id);
}

function getConsultationId() {
    return localStorage.getItem('latestConsultationId');
}

function setConsultationId(id) {
    localStorage.setItem('latestConsultationId', id);
}
