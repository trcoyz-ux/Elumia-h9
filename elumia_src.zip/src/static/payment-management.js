document.addEventListener('DOMContentLoaded', () => {
    const walletBalanceEl = document.getElementById('wallet-balance');
    const totalTransactionsEl = document.getElementById('total-transactions');
    const lastTransactionDateEl = document.getElementById('last-transaction-date');
    const transactionListEl = document.getElementById('transaction-list');
    const paymentModal = document.getElementById('paymentModal');
    const addFundsBtn = document.getElementById('add-funds-btn');
    const closeBtn = document.querySelector('.close');
    const paymentForm = document.getElementById('paymentForm');
    const transactionFilter = document.getElementById('transaction-filter');

    // تهيئة البيانات من localStorage
    let walletData = JSON.parse(localStorage.getItem('elumia_wallet') || '{"balance": 0, "transactions": []}');

    function updateUI(filter = 'all') {
        // تحديث الرصيد
        if (walletBalanceEl) {
            walletBalanceEl.textContent = `${walletData.balance.toFixed(2)} ر.ي`;
        }

        // تحديث إحصائيات العمليات
        if (totalTransactionsEl) {
            totalTransactionsEl.textContent = walletData.transactions.length;
        }

        if (lastTransactionDateEl && walletData.transactions.length > 0) {
            const lastDate = walletData.transactions[walletData.transactions.length - 1].date;
            lastTransactionDateEl.textContent = lastDate.split(',')[0]; // عرض التاريخ فقط بدون الوقت
        } else if (lastTransactionDateEl) {
            lastTransactionDateEl.textContent = '-';
        }
        
        // تصفية العمليات
        let filteredTransactions = walletData.transactions;
        if (filter !== 'all') {
            filteredTransactions = walletData.transactions.filter(t => t.type === filter);
        }

        // تحديث جدول العمليات
        if (transactionListEl) {
            if (filteredTransactions.length === 0) {
                transactionListEl.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 40px; color: var(--text-light);">لا توجد معاملات حالياً</td></tr>';
            } else {
                transactionListEl.innerHTML = filteredTransactions.map(t => `
                    <tr>
                        <td><span style="font-family: monospace; font-weight: bold;">${t.id}</span></td>
                        <td>${t.date}</td>
                        <td>
                            <span class="type-badge ${t.type}">
                                ${t.type === 'deposit' ? '<i class="fas fa-arrow-down"></i> شحن' : 
                                  t.type === 'payment' ? '<i class="fas fa-shopping-cart"></i> دفع' : 
                                  '<i class="fas fa-arrow-up"></i> سحب'}
                            </span>
                        </td>
                        <td>${t.description}</td>
                        <td style="color: ${t.type === 'deposit' ? '#2e7d32' : '#c62828'}; font-weight: 800;">
                            ${t.type === 'deposit' ? '+' : '-'}${t.amount.toFixed(2)} ر.ي
                        </td>
                        <td><span class="status-badge completed">مكتمل</span></td>
                    </tr>
                `).reverse().join('');
            }
        }
    }

    // معالجة الفلتر
    if (transactionFilter) {
        transactionFilter.addEventListener('change', (e) => {
            updateUI(e.target.value);
        });
    }

    // فتح المودال
    if (addFundsBtn) {
        addFundsBtn.addEventListener('click', () => {
            paymentModal.style.display = 'block';
        });
    }

    // إغلاق المودال
    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            paymentModal.style.display = 'none';
        });
    }

    window.addEventListener('click', (e) => {
        if (e.target === paymentModal) {
            paymentModal.style.display = 'none';
        }
    });

    // معالجة نموذج الدفع
    if (paymentForm) {
        paymentForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const amount = parseFloat(document.getElementById('amount').value);
            const method = document.querySelector('input[name="method"]:checked').value;

            if (amount > 0) {
                const newTransaction = {
                    id: 'TRX-' + Math.random().toString(36).substr(2, 6).toUpperCase(),
                    date: new Date().toLocaleString('ar-EG'),
                    type: 'deposit',
                    description: `شحن رصيد عبر ${method.toUpperCase()}`,
                    amount: amount,
                    status: 'completed'
                };

                walletData.balance += amount;
                walletData.transactions.push(newTransaction);
                
                localStorage.setItem('elumia_wallet', JSON.stringify(walletData));
                
                const methodNames = {stripe:'Stripe', paypal:'PayPal', onecash:'ون كاش', jawaly:'جوالي', mobilemoney:'موبايل موني', jib:'جيب', yemenwallet:'يمن والت'};
                alert(`تم شحن ${amount} ر.ي بنجاح عبر ${methodNames[method] || method}`);
                paymentModal.style.display = 'none';
                paymentForm.reset();
                updateUI(transactionFilter ? transactionFilter.value : 'all');
            }
        });
    }

    updateUI();
});
